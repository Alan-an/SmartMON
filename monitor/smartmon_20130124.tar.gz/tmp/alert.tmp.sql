insert into alerts values ('20130124182541','caolu', 'txy3a[242.100] cpu=92;');
insert into alerts values ('20130124182541','caolu', 'tyy1b[242.12] 14 db file scattered read. 4493 user sessions.;');
