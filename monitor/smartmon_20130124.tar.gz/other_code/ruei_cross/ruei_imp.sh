impdp uxinsight/oracle dumpfile=WG__BIDATA_PERIOD.dmp logfile=WG__BIDATA_PERIOD.log parallel=10 directory=ruei_imp remap_tablespace=USERS:SUNL_MON
impdp uxinsight/oracle dumpfile=WG__BIDATA_USERFLOW_PERIOD.dmp logfile=WG__BIDATA_USERFLOW_PERIOD.log parallel=10 directory=ruei_imp remap_tablespace=USERS:SUNL_MON
impdp uxinsight/oracle dumpfile=WG__BIDATA_PROPERTIES.dmp logfile=WG__BIDATA_PROPERTIES.log parallel=10 directory=ruei_imp remap_tablespace=USERS:SUNL_MON
impdp uxinsight/oracle dumpfile=WG__BIDATA_MASTER.dmp logfile=WG__BIDATA_MASTER.log parallel=10 directory=ruei_imp remap_tablespace=USERS:SUNL_MON
impdp uxinsight/oracle dumpfile=WG__BIDATA_USERFLOWS.dmp logfile=WG__BIDATA_USERFLOWS.log parallel=10 directory=ruei_imp remap_tablespace=USERS:SUNL_MON
